#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Music {
    char artist[100];
    char song[100];
    struct Music* next;
    struct Music* prev;
};

struct Music* head = NULL;
struct Music* current = NULL;

// Função para criar um novo nó de música
struct Music* createMusic(const char* artist, const char* song) {
    struct Music* newMusic = (struct Music*)malloc(sizeof(struct Music));
    if (newMusic == NULL) {
        perror("Falha na alocação de memória");
        exit(1);
    }
    strcpy(newMusic->artist, artist);
    strcpy(newMusic->song, song);
    newMusic->next = NULL;
    newMusic->prev = NULL;
    return newMusic;
}

// Função para adicionar uma música à lista
void addMusic(const char* artist, const char* song) {
    struct Music* newMusic = createMusic(artist, song);

    if (head == NULL) {
        head = newMusic;
        head->next = head;
        head->prev = head;
        current = head;
    } else {
        newMusic->next = head;
        newMusic->prev = head->prev;
        head->prev->next = newMusic;
        head->prev = newMusic;
    }
}

// Função para exibir a lista de músicas na ordem de cadastro
void displayPlaylist() {
    if (head == NULL) {
        printf("A playlist está vazia.\n");
        return;
    }

    struct Music* currentMusic = head;
    do {
        printf("Artista: %s, Música: %s\n", currentMusic->artist, currentMusic->song);
        currentMusic = currentMusic->next;
    } while (currentMusic != head);
}

// Função para exibir a lista de músicas ordenada pelo nome das músicas
void displaySortedPlaylist() {
    if (head == NULL) {
        printf("A playlist está vazia.\n");
        return;
    }

    // Copiar os nós da lista para um array
    struct Music* currentMusic = head;
    int count = 0;
    do {
        count++;
        currentMusic = currentMusic->next;
    } while (currentMusic != head);

    struct Music** musicArray = (struct Music**)malloc(count * sizeof(struct Music*));
    if (musicArray == NULL) {
        perror("Falha na alocação de memória");
        exit(1);
    }

    currentMusic = head;
    int i = 0;
    do {
        musicArray[i] = currentMusic;
        currentMusic = currentMusic->next;
        i++;
    } while (currentMusic != head);

    // Função de comparação para ordenar as músicas pelo nome
    int compareMusicNames(const void* a, const void* b) {
        return strcmp(((struct Music*)a)->song, ((struct Music*)b)->song);
    }

    qsort(musicArray, count, sizeof(struct Music*), compareMusicNames);

    for (i = 0; i < count; i++) {
        printf("Artista: %s, Música: %s\n", musicArray[i]->artist, musicArray[i]->song);
    }

    free(musicArray);
}

// Função para avançar para a próxima música
void nextSong() {
    if (current == NULL) {
        printf("A playlist está vazia.\n");
        return;
    }

    current = current->next;
    printf("Próxima música: Artista - %s, Música - %s\n", current->artist, current->song);
}

// Função para retornar à música anterior
void previousSong() {
    if (current == NULL) {
        printf("A playlist está vazia.\n");
        return;
    }

    current = current->prev;
    printf("Música anterior: Artista - %s, Música - %s\n", current->artist, current->song);
}

// Função para inserir uma nova música na lista e no arquivo
void insertMusic(const char* filename) {
    char artist[100];
    char song[100];

    printf("Digite o nome do artista: ");
    scanf("%s", artist);
    printf("Digite o nome da música: ");
    scanf("%s", song);

    addMusic(artist, song);

    FILE* file = fopen(filename, "a");
    if (file == NULL) {
        perror("Erro ao abrir o arquivo para escrita");
        return;
    }

    fprintf(file, "%s;%s\n", artist, song);
    fclose(file);
}

// Função para remover uma música da lista e do arquivo
void removeMusic(const char* filename) {
    if (head == NULL) {
        printf("A playlist está vazia.\n");
        return;
    }

    char artist[100];
    char song[100];

    printf("Digite o nome do artista da música a ser removida: ");
    scanf("%s", artist);
    printf("Digite o nome da música a ser removida: ");
    scanf("%s", song);

    struct Music* currentMusic = head;
    struct Music* musicToRemove = NULL;

    do {
        if (strcmp(currentMusic->artist, artist) == 0 && strcmp(currentMusic->song, song) == 0) {
            musicToRemove = currentMusic;
            break;
        }
        currentMusic = currentMusic->next;
    } while (currentMusic != head);

    if (musicToRemove) {
        if (musicToRemove == head) {
            head = musicToRemove->next;
        }
        if (musicToRemove == current) {
            current = musicToRemove->next;
        }

        musicToRemove->prev->next = musicToRemove->next;
        musicToRemove->next->prev = musicToRemove->prev;

        free(musicToRemove);

        FILE* file = fopen(filename, "r");
        FILE* tempFile = fopen("temp.txt", "w");
        if (file == NULL || tempFile == NULL) {
            perror("Erro ao abrir os arquivos para manipulação");
            return;
        }

        char line[300];
              while (fgets(line, sizeof(line), file)) {
                  char storedArtist[100];
                  char storedSong[100];
                  sscanf(line, "%99[^;];%99[^\n]", storedArtist, storedSong);

                  if (strcmp(storedArtist, artist) != 0 || strcmp(storedSong, song) != 0) {
                      fprintf(tempFile, "%s;%s\n", storedArtist, storedSong);
                  }
              }

              fclose(file);
              fclose(tempFile);

              if (remove(filename) != 0) {
                  perror("Erro ao remover o arquivo original");
                  return;
              }

              if (rename("temp.txt", filename) != 0) {
                  perror("Erro ao renomear o arquivo temporário");
                  return;
              }
          } else {
              printf("Música não encontrada.\n");
          }
      }

      // Função para salvar a playlist no arquivo
      void saveToFile(const char* filename) {
          FILE* file = fopen(filename, "w");
          if (file == NULL) {
              perror("Erro ao abrir o arquivo para escrita");
              return;
          }

          struct Music* currentMusic = head;
          do {
              fprintf(file, "%s;%s\n", currentMusic->artist, currentMusic->song);
              currentMusic = currentMusic->next;
          } while (currentMusic != head);

          fclose(file);
      }

      int main() {
          char filename[] = "musicas.txt";

          FILE* file = fopen(filename, "r");
          if (file != NULL) {
              char artist[100];
              char song[100];

              while (fscanf(file, "%99[^;];%99[^\n]\n", artist, song) == 2) {
                  addMusic(artist, song);
              }

              fclose(file);
          }

          int choice;
          while (1) {
              printf("\nMenu:\n");
              printf("1. Exibir a playlist na ordem de cadastro\n");
              printf("2. Exibir a playlist ordenada pelo nome das músicas\n");
              printf("3. Inserir nova música\n");
              printf("4. Remover uma música\n");
              printf("5. Avançar para a próxima música\n");
              printf("6. Retornar à música anterior\n");
              printf("7. Salvar e sair\n");

              printf("Escolha uma opção: ");
              scanf("%d", &choice);

              switch (choice) {
                  case 1:
                      displayPlaylist();
                      break;
                  case 2:
                      displaySortedPlaylist();
                      break;
                  case 3:
                      insertMusic(filename);
                      break;
                  case 4:
                      removeMusic(filename);
                      break;
                  case 5:
                      nextSong();
                      break;
                  case 6:
                      previousSong();
                      break;
                  case 7:
                      saveToFile(filename);
                      exit(0);
                  default:
                      printf("Opção inválida. Tente novamente.\n");
              }
          }

          return 0;
      }



